create definer = root@localhost trigger explore_our_offering_BEFORE_UPDATE
    before update
    on explore_our_offering
    for each row
BEGIN
if new.data_create <>old.data_create then
	signal sqlstate '48101' set  message_text='Your cant not  edit this is field  ';
 end if;
set new.date_last_update=sysdate();
END;

